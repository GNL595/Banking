package com.cg.banking.beans;
public class Customer {
	private int customerId;
	private Address localAddress,homeAddress;
	private Account[] accounts=new Account[3];
	private float firstName,lastName,mobileNo,emailId,adharNo,pancardNo,dateOfBirth;
	public Customer() {}
	public Customer(int customerId, Address localAddress, Address homeAddress, Account[] accounts, float firstName,
			float lastName, float mobileNo, float emailId, float adharNo, float pancardNo, float dateOfBirth) {
		super();
		this.customerId = customerId;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
		this.accounts = accounts;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public Address getLocalAddress() {
		return localAddress;
	}
	public void setLocalAddress(Address localAddress) {
		this.localAddress = localAddress;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	public Account[] getAccounts() {
		return accounts;
	}
	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
	public float getFirstName() {
		return firstName;
	}
	public void setFirstName(float firstName) {
		this.firstName = firstName;
	}
	public float getLastName() {
		return lastName;
	}
	public void setLastName(float lastName) {
		this.lastName = lastName;
	}
	public float getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(float mobileNo) {
		this.mobileNo = mobileNo;
	}
	public float getEmailId() {
		return emailId;
	}
	public void setEmailId(float emailId) {
		this.emailId = emailId;
	}
	public float getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(float adharNo) {
		this.adharNo = adharNo;
	}
	public float getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(float pancardNo) {
		this.pancardNo = pancardNo;
	}
	public float getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(float dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
}